from greedy.player import Player
